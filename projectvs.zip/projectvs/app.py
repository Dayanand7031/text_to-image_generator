from flask import Flask, jsonify
import openai
from config import key
from flask import Flask, render_template, url_for, request, redirect,session
from flask_mysqldb import MySQL
from flask_login import UserMixin


app = Flask(__name__)
openai.api_key = key

# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
# db = SQLAlchemy(app)

# class User(db.Model):
#     id = db.Column(db.Integer,primary_key=False)
#     username = db.Column(db.String(20), nullable=False)
#     password = db.Column(db.String(80), nullable=False)


app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flask_users'

mysql = MySQL(app)

@app.route('/')
def home():
    if 'username' in session:
        return render_template('home.html',username =session['username'])
    else:
        return render_template('home.html')

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        pwd = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute(f"select username, password from tbl_users where username =  '{username}'")
        user = cur.fetchone()
        cur.close()
        if user and pwd == user[1]:
            session['username'] = user[0]
            return redirect(url_for('info'))
        else:
            return render_template('login.html', error = 'Invalid username or password')
    return render_template('login.html')


@app.route('/register',methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        pwd = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute(f"insert into tbl_users (Username,password) values ('{username}','{pwd}')")
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('username',None)
    return redirect(url_for('home'))


@app.route('/info')
def info():
  if 'username' in session:
    return render_template('info.html',username =session['username'])
  else:
    return render_template('login.html')
#   return render_template('info.html')


@app.route('/about')
def about():
  if 'username' in session:
    return render_template('about.html',username =session['username'])
  else:
    return render_template('about.html')

@app.route('/gallery')
def gallery():
  if 'username' in session:
    return render_template('gallery.html',username =session['username'])
  else:
    return render_template('gallery.html')


@app.route('/generateimages/<prompt>')
def generate(prompt):
  print("prompt", prompt)
  response = openai.images.generate(prompt=prompt, n=1, size="1024x1024")
  print(response)
  return jsonify(response)



if __name__ == '_main_':
    app.run(debug=True)
# @app.route('/')
# def home():
#     return render_template('home.html')

# @app.route('/login')
# def login():
#     return render_template('login.html')

# @app.route('/register')
# def register():
#     return render_template('register.html')

# if _name_ == '_main_':
#     app.run(debug=True)

