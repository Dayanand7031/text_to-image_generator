import os
import openai
from config import key

openai.api_key = key
response = openai.images.generate(prompt="cute cat", n=1, size="1024x1024")

print(response)